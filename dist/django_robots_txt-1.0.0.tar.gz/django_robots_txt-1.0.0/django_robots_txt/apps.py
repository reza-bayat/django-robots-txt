from django.apps import AppConfig

class RobotsTxtConfig(AppConfig):
    name = 'django_robots_txt'
    verbose_name = 'Robots.txt Manager'